# from django.shortcuts import render
# from django.http import HttpResponse


# def index(request):
#     return HttpResponse("Hello, This is Asbah.")


from django.http import HttpResponse
from .models import Book,User,Borrow_Books,Return_Books
from django.template import loader
from django.shortcuts import render,get_object_or_404
def index(request):
    all_book=Book.objects.all()
    context={
            'all_book':all_book
    }
    return render(request,'web/index.html',context)

def details(request,album_id):
    books=get_object_or_404(Book,pk=album_id)
    return render(request,'web/detail.html',{'book':books})

def favourite(request,ID):
    book=get_object_or_404(Book,pk=ID)
    selected_book=book.book_set.get(pk=request.POST['book'])
    selected_book.book_status='Booked'
    selected_book.save()
    return render(request,'web/confirm.html',{'book':book})

