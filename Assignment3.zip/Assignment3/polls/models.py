from django.db import models

# Create your models here.

class Book(models.Model):
    b_name = models.CharField(max_length=50)
    author = models.CharField(max_length=50)
    book_status=models.CharField(default="Available",max_length=20)
    def __str__(self):
        return self.b_name

class Borrow_Books(models.Model):
	borr_book=models.CharField(max_length=50)
	def __str__(self):
		return self.borr_book

class Return_Books(models.Model):
	return_book=models.CharField(max_length=50)
	def __str__(self):
		return self.return_book

class User(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    name = models.ForeignKey(Book, on_delete=models.CASCADE)

