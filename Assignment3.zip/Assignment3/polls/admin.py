from django.contrib import admin
from .models import Book, User,Borrow_Books,Return_Books

# Register your models here.
admin.site.register(Book)
admin.site.register(User)
admin.site.register(Borrow_Books)
admin.site.register(Return_Books)